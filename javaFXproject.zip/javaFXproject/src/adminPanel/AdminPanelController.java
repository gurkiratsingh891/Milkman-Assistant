package adminPanel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import customerRegistration.Data;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class AdminPanelController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField pwd;

 

   
 

    @FXML
    private ImageView pwdEx;

   


    @FXML
    private PasswordField pwdV;

    @FXML
    private Button proceed;
    
    

    Connection con;
    PreparedStatement pst;
    
    void doConnection()
    {
    	try {
 		Class.forName("com.mysql.jdbc.Driver");
 		con=DriverManager.getConnection("jdbc:mysql://localhost/angular2018",Data.uid,Data.pwd);
 		System.out.println("Connected");
 	} catch (ClassNotFoundException | SQLException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
    }


    
    


 
    
    @FXML
    void doForget(ActionEvent event) {
    	smsDone_new.main(null);
    	showAlert("SMS containing password sent to your number 8847670501");

    }

   

    @FXML
    void doLogin(ActionEvent event) {
    	System.out.println(pwd.getText());
    	  if(pwd.getText().equals(""))
          {
          		showAlert("Plz enter password");
          		
          }
    	  else if(pwd.getText().equals("milkman1234")==false)
    	  {
    		  showAlert("Wrong password");
    	  }
    	  else
    	  {
    		  try{
    	    		
    				Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("dashboard/Dashboard.fxml")); 
    				Scene scene = new Scene(root);
    				
    				Stage stage=new Stage();

    				stage.setScene(scene);
    				
    				stage.show();

    				//to hide the opened window
    				 
    				 /*  Scene scene1=(Scene)proceed.getScene();
    				   scene1.getWindow().hide();*/
    				 

    			}
    			catch(Exception e)
    			{
    				e.printStackTrace();
    			}
    	  }
    }

    @FXML
    void doSync1(KeyEvent event) {
    	pwdV.setText(pwd.getText());
    }
  
   
    @FXML
    void doSync(KeyEvent event) 
    {
    	pwd.setText(pwdV.getText());
    
    }
    int flag=0;
    @FXML
    void pwdVis(MouseEvent event) {
    	if(flag==0)
    		{
    			pwd.setVisible(true);
    			pwdV.setVisible(false);
    			flag=1;
    		}
    	else
    	{
    		pwdV.setVisible(true);
    		pwd.setVisible(false);
    		flag=0;
    	}
    	
    }
   

   
    


    
    
    void showAlert(String msg)
	{
		Alert alert=new Alert(Alert.AlertType.INFORMATION);
		alert.setContentText(msg);
		alert.show();
		
	}
    

		
		
		
		
	

    @FXML
    void initialize() {
        assert pwd != null : "fx:id=\"pwd\" was not injected: check your FXML file 'AdminPanel.fxml'.";
    doConnection();
        assert pwdEx != null : "fx:id=\"pwdEx\" was not injected: check your FXML file 'AdminPanel.fxml'.";
    }
}
