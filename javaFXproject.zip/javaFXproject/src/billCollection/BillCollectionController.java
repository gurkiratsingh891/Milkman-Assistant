package billCollection;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import billLog.billBean;
import billLog.bill_historyBean;
import customerRegistration.Data;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

public class BillCollectionController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<Integer> comboMonth;

    @FXML
    private ComboBox<Integer> comboYear;

    @FXML
    private ComboBox<String> comboMobile;

    @FXML
    private TextField txtBill;
    Connection con;
    PreparedStatement pst;
    ObservableList<bill_historyBean> list=FXCollections.observableArrayList();
    ObservableList<billBean> list1=FXCollections.observableArrayList();

    
    void doConnection()
    {
    	try {
 		Class.forName("com.mysql.jdbc.Driver");
 		con=DriverManager.getConnection("jdbc:mysql://localhost/javafxproject",Data.uid,Data.pwd);
 		System.out.println("Connected");
 	} catch (ClassNotFoundException | SQLException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
    }
    @FXML
    void doFilter(KeyEvent event) {
    	String a=comboMobile.getEditor().getText();
    	if(a.equals(""))
    	{
    		doFillMobiles();
    		return;
    	}
    	a="%"+a+"%";
    	ArrayList<String> mobiles=new ArrayList<>();
		try {
			pst=con.prepareStatement("select mobile from customers where mobile like ?");
			pst.setString(1, a);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String r=rs.getString("mobile");
				mobiles.add(r);
			}
			
			comboMobile.getItems().clear();
			comboMobile.getItems().addAll(mobiles);
			
			
	    }
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
    }
    void doFill()
    {
    	ArrayList<Integer> allmonths=new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12));
    	comboMonth.getItems().addAll(allmonths);
    	ArrayList<Integer>allyears=new ArrayList<>(Arrays.asList(2016,2017,2018,2019,2020,2021,2022,2023,2024,2025));
    	comboYear.getItems().addAll(allyears);
    	Integer a=LocalDate.now().getYear();
    	Integer b=LocalDate.now().getMonthValue();
    	b=b-1;
    	if(b==0)
    	{
    		b=12;
    		a=a-1;
    	}
    	comboYear.getSelectionModel().select(a);
    	comboMonth.getSelectionModel().select(b);
		
    }

	void doFillMobiles()
	{
    	ArrayList<String> mobiles=new ArrayList<>();
		try {
			pst=con.prepareStatement("select distinct mobile from customers");
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String r=rs.getString("mobile");
				mobiles.add(r);
			}
			
			comboMobile.getItems().clear();
			comboMobile.getItems().addAll(mobiles);
			
	    }
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
	}
    void showAlert(String msg)
   	{
   		Alert alert=new Alert(Alert.AlertType.INFORMATION);
   		alert.setContentText(msg);
   		alert.show();
   	}


    @FXML
    void doUpdate(ActionEvent event) {
    	try {
			pst=con.prepareStatement("update bill_history set received=? where mobile=? and month=? and year=?");
			pst.setInt(1, 1);
			pst.setString(2, comboMobile.getSelectionModel().getSelectedItem());
			pst.setInt(3, comboMonth.getSelectionModel().getSelectedItem());
			pst.setInt(4, comboYear.getSelectionModel().getSelectedItem());
			int a=pst.executeUpdate();
			
if(a!=0)
	{showAlert("Bill Collection updated");		
	}   }
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
    }

    @FXML
    void findAmount(ActionEvent event) {
    	if(comboMobile.getSelectionModel().getSelectedItem()==null)
    	{
    		showAlert("Plz enter mobile number");
    		return;
    	}
    	try {
			pst=con.prepareStatement("select totalbill from bill_history where mobile=? and received=? and month=? and year=?");
			pst.setString(1, comboMobile.getSelectionModel().getSelectedItem());
			pst.setInt(2, 0);
			pst.setInt(3, comboMonth.getSelectionModel().getSelectedItem());
			pst.setInt(4, comboYear.getSelectionModel().getSelectedItem());

			float bill=0.0f;
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				float r=rs.getFloat("totalbill");
				System.out.println(r);
				bill+=r;
			}
			txtBill.setText(String.valueOf(bill));
			
			
	    }
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
    }

    @FXML
    void initialize() {
        assert comboMonth != null : "fx:id=\"comboMonth\" was not injected: check your FXML file 'BillCollection.fxml'.";
        assert comboYear != null : "fx:id=\"comboYear\" was not injected: check your FXML file 'BillCollection.fxml'.";
        assert comboMobile != null : "fx:id=\"comboMobile\" was not injected: check your FXML file 'BillCollection.fxml'.";
        assert txtBill != null : "fx:id=\"txtBill\" was not injected: check your FXML file 'BillCollection.fxml'.";
        doConnection();
        doFill();
        doFillMobiles();
    }
}
