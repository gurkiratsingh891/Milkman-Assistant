package billLog;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import customerFinder.CustomersBean;
import customerRegistration.Data;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.FileChooser;

public class BillLogController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<Integer> comboMonth;

    @FXML
    private ComboBox<Integer> comboYear;
    
    @FXML
    private ComboBox<String> comboMobile;

    @FXML
    private RadioButton radioPaid;

    @FXML
    private RadioButton radioPending;

    @FXML
    private TableView<bill_historyBean> tbl;

    @FXML
    private TableView<billBean> tbl1;
    
    Connection con;
    PreparedStatement pst;
    ObservableList<bill_historyBean> list=FXCollections.observableArrayList();
    ObservableList<billBean> list1=FXCollections.observableArrayList();
 int flag123=0;
    
    void doConnection()
    {
    	try {
 		Class.forName("com.mysql.jdbc.Driver");
 		con=DriverManager.getConnection("jdbc:mysql://localhost/javafxproject",Data.uid,Data.pwd);
 		System.out.println("Connected");
 	} catch (ClassNotFoundException | SQLException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
    }

    @FXML
    void doBillHistory(ActionEvent event) {
    	if(comboMobile.getSelectionModel().getSelectedItem()==null)
    	{
    		showAlert("plz select mobile number");
    				return;
    	}
    	list1.clear();
    	try {
    		pst=con.prepareStatement("select * from bill_history where mobile=?");
    		pst.setString(1, comboMobile.getSelectionModel().getSelectedItem());
    		
    		ResultSet rs=pst.executeQuery();
    		while(rs.next())
    		{
   				float totalbill=rs.getFloat("totalBill");
   				int received=rs.getInt("received"); 	
   				int month=rs.getInt("month"); 	
   				int year=rs.getInt("year"); 	
   				String mobile=rs.getString("mobile");
   				
   				billBean bean=new billBean(mobile,totalbill,received,month,year
   						 );
   				list1.add(bean);
    		}
    		doTable2(list1);
    		tbl1.setVisible(true);
    		tbl.setVisible(false);
    		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    void doTable2(ObservableList<billBean>list)
    {
tbl.getColumns().clear();
    	
    	TableColumn<billBean, String> mobileCol=new TableColumn<billBean, String>("Mobile");
    	mobileCol.setCellValueFactory(new PropertyValueFactory<>("mobile"));//field name in bean
    	mobileCol.setMinWidth(100);
    	
    	TableColumn<billBean, Float> totalCol=new TableColumn<billBean, Float>("Bill");
    	totalCol.setCellValueFactory(new PropertyValueFactory<>("totalbill"));//field name in bean
    	totalCol.setMinWidth(100);
    
    	TableColumn<billBean, Integer> receivedCol=new TableColumn<billBean,Integer>("Bill Status");
    	receivedCol.setCellValueFactory(new PropertyValueFactory<>("received"));//field name in bean
    	receivedCol.setMinWidth(100);
    	TableColumn<billBean, Integer> monthCol=new TableColumn<billBean,Integer>("Month");
    	monthCol.setCellValueFactory(new PropertyValueFactory<>("month"));//field name in bean
    	monthCol.setMinWidth(100);
    	TableColumn<billBean, Integer> yearCol=new TableColumn<billBean,Integer>("Year");
    	yearCol.setCellValueFactory(new PropertyValueFactory<>("year"));//field name in bean
    	yearCol.setMinWidth(100);
    	flag123=2;
    	
    	tbl1.getColumns().addAll(mobileCol,totalCol,receivedCol,monthCol,yearCol);
    	tbl1.setItems(list1);
    }

    @FXML
    void doExport(ActionEvent event) {
    	if(flag123==1)
			try {
				writeExcel1();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		else if(flag123==2)
			try {
				writeExcel2();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	
    		

    }
    public void writeExcel2()  throws Exception {
        Writer writer = null;
        try {
        	FileChooser chooser=new FileChooser();
	    	
        	chooser.setTitle("Select Path:");
        	
        	chooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("All Files", "*.*")
                    
                );
        	 File file=chooser.showSaveDialog(null);
        	String filePath=file.getAbsolutePath();
        	if(!(filePath.endsWith(".csv")||filePath.endsWith(".CSV")))
        	{
        		showAlert("file name should have .csv extension");
        		return;
        	}
        	 file = new File(filePath);        	 
            writer = new BufferedWriter(new FileWriter(file));
            String text="Mobile,Bill,Bill Status,Month,Year\n";
            writer.write(text);
            for (billBean p : list1)
            {
				text = p.getMobile()+ "," + p.getTotalbill()+ ","  + p.getReceived()+ "," + p.getMonth()+ 
						"," + p.getYear() +"\n";
                writer.write(text);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        finally {
           
            writer.flush();
             writer.close();
        }
    }

    @FXML
    void doFetch(ActionEvent event) {
    	list.clear();
    	if(comboMonth.getSelectionModel().getSelectedItem()==null)
    	{
    		showAlert("plz select month");
    				return;
    	}
    	try {
    		pst=con.prepareStatement("select * from bill_history where month=? and year=?");
    		pst.setInt(1, comboMonth.getSelectionModel().getSelectedItem());
    		pst.setInt(2, comboYear.getSelectionModel().getSelectedItem());

    		ResultSet rs=pst.executeQuery();
    		while(rs.next())
    		{
    			String mobile=rs.getString("mobile");
        		pst=con.prepareStatement("select * from customers where mobile=?");
        		pst.setString(1, mobile);
        		ResultSet rs1=pst.executeQuery();
        		rs1.next();
        		
   				float totalbill=rs.getFloat("totalBill");
   				int received=rs.getInt("received"); 	
   				int month=rs.getInt("month"); 	
   				System.out.println(month);
   				int year=rs.getInt("year"); 	
   				String cname=rs1.getString("cname");
   				String address=rs1.getString("address");
   				String area=rs1.getString("area");
   				bill_historyBean bean=new bill_historyBean(cname,mobile,totalbill,received,month,year,address,
   						 area);
   				list.add(bean);
    		}
    		doTable1(list);
    		tbl1.setVisible(false);
    		tbl.setVisible(true);
    		flag123=1;
    		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    void doTable1(ObservableList<bill_historyBean>list)
    {
tbl.getColumns().clear();
    	
    	TableColumn<bill_historyBean, String> mobileCol=new TableColumn<bill_historyBean, String>("Mobile");
    	mobileCol.setCellValueFactory(new PropertyValueFactory<>("mobile"));//field name in bean
    	mobileCol.setMinWidth(100);
    	
    	TableColumn<bill_historyBean, String> cnameCol=new TableColumn<bill_historyBean, String>("Name");
    	cnameCol.setCellValueFactory(new PropertyValueFactory<>("cname"));//field name in bean
    	cnameCol.setMinWidth(100);
    	
    	
    	TableColumn<bill_historyBean, String> addressCol=new TableColumn<bill_historyBean, String>("Address");
    	addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));//field name in bean
    	addressCol.setMinWidth(100);
    	
    	
    	TableColumn<bill_historyBean, String> areaCol=new TableColumn<bill_historyBean, String>("Area");
    	areaCol.setCellValueFactory(new PropertyValueFactory<>("area"));//field name in bean
    	areaCol.setMinWidth(100);
    	
    	TableColumn<bill_historyBean, Float> totalCol=new TableColumn<bill_historyBean, Float>("Bill");
    	totalCol.setCellValueFactory(new PropertyValueFactory<>("totalbill"));//field name in bean
    	totalCol.setMinWidth(100);
    
    	TableColumn<bill_historyBean,Integer> receivedCol=new TableColumn<bill_historyBean,Integer>("Bill Status");
    	receivedCol.setCellValueFactory(new PropertyValueFactory<>("received"));//field name in bean
    	receivedCol.setMinWidth(100);
    	TableColumn<bill_historyBean,Integer> monthCol=new TableColumn<bill_historyBean,Integer>("Month");
    	monthCol.setCellValueFactory(new PropertyValueFactory<>("month"));//field name in bean
    	monthCol.setMinWidth(100);
    	TableColumn<bill_historyBean,Integer> yearCol=new TableColumn<bill_historyBean,Integer>("Year");
    	yearCol.setCellValueFactory(new PropertyValueFactory<>("year"));//field name in bean
    	yearCol.setMinWidth(100);
    	flag123=1;
    	
    	tbl.getColumns().addAll(cnameCol,mobileCol,totalCol,receivedCol,monthCol,yearCol,addressCol,areaCol);
    	tbl.setItems(list);
    }
    public void writeExcel1()  throws Exception {
        Writer writer = null;
        try {
        	FileChooser chooser=new FileChooser();
	    	
        	chooser.setTitle("Select Path:");
        	
        	chooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("All Files", "*.*")
                    
                );
        	 File file=chooser.showSaveDialog(null);
        	String filePath=file.getAbsolutePath();
        	if(!(filePath.endsWith(".csv")||filePath.endsWith(".CSV")))
        	{
        		showAlert("file name should have .csv extension");
        		return;
        	}
        	 file = new File(filePath);        	 
            writer = new BufferedWriter(new FileWriter(file));
            String text="Name,Mobile,Total Bill,Bill Status,Month,Year,Address,Area\n";
            writer.write(text);
            for (bill_historyBean p : list)
            {
				text = p.getCname()+ "," + p.getMobile()+ "," + p.getTotalbill()+ "," + p.getReceived()+ "," + p.getMonth()+ 
						"," + p.getYear()+ "," + p.getAddress()+ "," + p.getArea()+"\n";
                writer.write(text);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        finally {
           
            writer.flush();
             writer.close();
        }
    }

    @FXML
    void doShow(ActionEvent event) {
    	int a;
    	if(comboMonth.getSelectionModel().getSelectedItem()==null)
    	{
    		showAlert("plz select month");
    				return;
    	}
    	
    	if(radioPaid.isSelected())
    		 a=1;
    	else if(radioPending.isSelected())
    		a=0;
    	else
    	{
    		showAlert("select any of pending or paid");
    		return;
    	}
    	list.clear();
    	try {
    		pst=con.prepareStatement("select * from bill_history where month=? and year=? and received=?");
    		pst.setInt(1, comboMonth.getSelectionModel().getSelectedItem());
    		pst.setInt(2, comboYear.getSelectionModel().getSelectedItem());
    		pst.setInt(3, a);
    		ResultSet rs=pst.executeQuery();
    		while(rs.next())
    		{
    			String mobile=rs.getString("mobile");
        		pst=con.prepareStatement("select * from customers where mobile=?");
        		pst.setString(1, mobile);
        		ResultSet rs1=pst.executeQuery();
        		rs1.next();
        		
   				float totalbill=rs.getFloat("totalBill");
   				int received=rs.getInt("received"); 	
   				int month=rs.getInt("month"); 	
   				int year=rs.getInt("year"); 	
   				String cname=rs1.getString("cname");
   				String address=rs1.getString("address");
   				String area=rs1.getString("area");
   				bill_historyBean bean=new bill_historyBean(cname,mobile,totalbill,received,month,year,address,
   						 area);
   				list.add(bean);
    		}
    		doTable1(list);
    		tbl1.setVisible(false);
    		tbl.setVisible(true);
    		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    
    @FXML
    void doFilter(KeyEvent event) {
    	String a=comboMobile.getEditor().getText();
    	if(a.equals(""))
    	{
    		doFillMobiles();
    		return;
    	}
    	a="%"+a+"%";
    	ArrayList<String> mobiles=new ArrayList<>();
		try {
			pst=con.prepareStatement("select mobile from customers where mobile like ?");
			pst.setString(1, a);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String r=rs.getString("mobile");
				mobiles.add(r);
			}
			
			comboMobile.getItems().clear();
			comboMobile.getItems().addAll(mobiles);
			tbl1.setVisible(false);
    		tbl.setVisible(true);
			
	    }
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
    	
    }
    
    void doFill()
    {
    	ArrayList<Integer> allmonths=new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12));
    	comboMonth.getItems().addAll(allmonths);
    	ArrayList<Integer>allyears=new ArrayList<>(Arrays.asList(2016,2017,2018,2019,2020,2021,2022,2023,2024,2025));
    	comboYear.getItems().addAll(allyears);
    	Integer a=LocalDate.now().getYear();
    	comboYear.getSelectionModel().select(a);
		
    }

	void doFillMobiles()
	{
    	ArrayList<String> mobiles=new ArrayList<>();
		try {
			pst=con.prepareStatement("select distinct mobile from customers");
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String r=rs.getString("mobile");
				mobiles.add(r);
			}
			
			comboMobile.getItems().clear();
			comboMobile.getItems().addAll(mobiles);
			
	    }
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
	}
    void showAlert(String msg)
   	{
   		Alert alert=new Alert(Alert.AlertType.INFORMATION);
   		alert.setContentText(msg);
   		alert.show();
   	}

    @FXML
    void initialize() {
        assert comboMonth != null : "fx:id=\"comboMonth\" was not injected: check your FXML file 'BillLog.fxml'.";
        assert comboYear != null : "fx:id=\"comboYear\" was not injected: check your FXML file 'BillLog.fxml'.";
        assert radioPaid != null : "fx:id=\"radioPaid\" was not injected: check your FXML file 'BillLog.fxml'.";
        assert radioPending != null : "fx:id=\"radioPending\" was not injected: check your FXML file 'BillLog.fxml'.";
        assert tbl != null : "fx:id=\"tbl\" was not injected: check your FXML file 'BillLog.fxml'.";
        doConnection();
        doFill();
        doFillMobiles();
        
    }
}
