package billLog;

public class billBean {
	String mobile;
	float totalbill;
	int received;
	int month;
	int year;
	billBean(){}
	public billBean(String mobile, float totalbill, int received, int month, int year) {
		super();
		this.mobile = mobile;
		this.totalbill = totalbill;
		this.received = received;
		this.month = month;
		this.year = year;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public float getTotalbill() {
		return totalbill;
	}
	public void setTotalbill(float totalbill) {
		this.totalbill = totalbill;
	}
	public int getReceived() {
		return received;
	}
	public void setReceived(int received) {
		this.received = received;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
}
