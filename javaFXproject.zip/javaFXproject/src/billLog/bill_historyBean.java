package billLog;

public class bill_historyBean {
	String mobile;
	float totalbill;
	int received;
	int month;
	int year;
	String address;
	String area;
	String cname;
	bill_historyBean()
	{
	
	}
	
	public bill_historyBean(String mobile, float totalbill, int received, int month, int year) {
		super();
		this.mobile = mobile;
		this.totalbill = totalbill;
		this.received = received;
		this.month = month;
		this.year = year;
	}

	public bill_historyBean(String mobile, float totalbill, int received, int month, int year, String address,
			String area, String cname) {
		super();
		this.mobile = mobile;
		this.totalbill = totalbill;
		this.received = received;
		this.month = month;
		this.year = year;
		this.address = address;
		this.area = area;
		this.cname = cname;
	}

	public bill_historyBean(String cname,String mobile, float totalbill, int received, int month, int year, String address,
			String area) {
		super();
		this.mobile = mobile;
		this.totalbill = totalbill;
		this.received = received;
		this.month = month;
		this.year = year;
		this.address = address;
		this.area = area;
		this.cname = cname;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public float getTotalbill() {
		return totalbill;
	}
	public void setTotalbill(float totalbill) {
		this.totalbill = totalbill;
	}
	public int getReceived() {
		return received;
	}
	public void setReceived(int received) {
		this.received = received;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	
	
	
}
