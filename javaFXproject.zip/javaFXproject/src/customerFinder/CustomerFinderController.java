
package customerFinder;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.ComboBoxModel;

import customerRegistration.Data;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.media.AudioClip;
import javafx.stage.FileChooser;


public class CustomerFinderController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> comboArea;

    @FXML
    private ComboBox<String> comboName;

    @FXML
    private TableView<CustomersBean> tbl;
    
    Connection con;
    PreparedStatement pst;
    URL url;
	AudioClip audio;
    ObservableList<CustomersBean> list=FXCollections.observableArrayList();
int flag123=0;


void playSound(){
	url=getClass().getResource("crash.wav");
	audio=new AudioClip(url.toString());
	audio.play();
}
    
    void doConnection()
    {
    	try {
 		Class.forName("com.mysql.jdbc.Driver");
 		con=DriverManager.getConnection("jdbc:mysql://localhost/javafxproject",Data.uid,Data.pwd);
 		System.out.println("Connected");
 	} catch (ClassNotFoundException | SQLException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
    }

    @FXML
    void doFetch(ActionEvent event) {
    	playSound();
    	list.clear();
    	if(comboArea.getSelectionModel().getSelectedItem()==null)
    	{
    		showAlert("plz select area");
    				return;
    	}
    	try {
			pst=con.prepareStatement("select * from customers where area=?");
			pst.setString(1, comboArea.getSelectionModel().getSelectedItem());
    		ResultSet rs=pst.executeQuery();
    		while(rs.next())
    		{
    			String mobile=rs.getString("mobile");
   				String cname=rs.getString("cname");
   				String address=rs.getString("address");
   				String area=rs.getString("area");
   				String city=rs.getString("city");
   				float cq=rs.getFloat("cq");
   				float cp=rs.getFloat("cp");
   				float bq=rs.getFloat("bq");
   				float bp=rs.getFloat("bp");
   				int status=rs.getInt("status"); 				
   				Date dop=rs.getDate("dos");
   				String dos=dop.toString();
   				CustomersBean bean=new CustomersBean(mobile,cname,address,area,city,cq,cp,bq,bp,status, dos);
   				list.add(bean);
    		}
    		doTable(list);
flag123=1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void doFetchAll(ActionEvent event) {
    	list.clear();
    	playSound();
    	try {
    		pst=con.prepareStatement("select * from customers");
    		ResultSet rs=pst.executeQuery();
    		while(rs.next())
    		{
    			String mobile=rs.getString("mobile");
   				String cname=rs.getString("cname");
   				String address=rs.getString("address");
   				String area=rs.getString("area");
   				String city=rs.getString("city");
   				float cq=rs.getFloat("cq");
   				float cp=rs.getFloat("cp");
   				float bq=rs.getFloat("bq");
   				float bp=rs.getFloat("bp");
   				int status=rs.getInt("status"); 				
   				Date dop=rs.getDate("dos");
   				String dos=dop.toString();
   				CustomersBean bean=new CustomersBean(mobile,cname,address,area,city,cq,cp,bq,bp,status, dos);
   				list.add(bean);
    		}
    		doTable(list);
    		flag123=1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }

    @FXML
    void doSearch(ActionEvent event) {
    	list.clear();
    	playSound();
    	if(comboName.getSelectionModel().getSelectedItem()==null)
    	{
    		showAlert("plz select name");
    				return;
    	}
    	try {
			String nm=comboName.getEditor().getText();
			nm="%"+nm+"%";
    		pst=con.prepareStatement("select * from customers where cname like ?");
    		pst.setString(1,nm);
    		ResultSet rs=pst.executeQuery();
    		while(rs.next())
    		{
    			String mobile=rs.getString("mobile");
   				String cname=rs.getString("cname");
   				String address=rs.getString("address");
   				String area=rs.getString("area");
   				String city=rs.getString("city");
   				float cq=rs.getFloat("cq");
   				float cp=rs.getFloat("cp");
   				float bq=rs.getFloat("bq");
   				float bp=rs.getFloat("bp");
   				int status=rs.getInt("status"); 				
   				Date dop=rs.getDate("dos");
   				String dos=dop.toString();
   				CustomersBean bean=new CustomersBean(mobile,cname,address,area,city,cq,cp,bq,bp,status, dos);
   				list.add(bean);
    		}
    		doTable(list);
    		flag123=1;
    
    		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    void doTable(ObservableList<CustomersBean>list)
    {
tbl.getColumns().clear();
    	
    	TableColumn<CustomersBean, String> mobileCol=new TableColumn<CustomersBean, String>("Mobile");
    	mobileCol.setCellValueFactory(new PropertyValueFactory<>("mobile"));//field name in bean
    	mobileCol.setMinWidth(100);
    	
    	TableColumn<CustomersBean, String> cnameCol=new TableColumn<CustomersBean, String>("Name");
    	cnameCol.setCellValueFactory(new PropertyValueFactory<>("cname"));//field name in bean
    	cnameCol.setMinWidth(100);
    	
    	
    	TableColumn<CustomersBean, String> addressCol=new TableColumn<CustomersBean, String>("Address");
    	addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));//field name in bean
    	addressCol.setMinWidth(100);
    	
    	
    	TableColumn<CustomersBean, String> areaCol=new TableColumn<CustomersBean, String>("Area");
    	areaCol.setCellValueFactory(new PropertyValueFactory<>("area"));//field name in bean
    	areaCol.setMinWidth(100);
    	
    	TableColumn<CustomersBean, String> cityCol=new TableColumn<CustomersBean, String>("City");
    	cityCol.setCellValueFactory(new PropertyValueFactory<>("city"));//field name in bean
    	cityCol.setMinWidth(100);
    	
    	TableColumn<CustomersBean, Float> cqCol=new TableColumn<CustomersBean, Float>("Cow Quantity");
    	cqCol.setCellValueFactory(new PropertyValueFactory<>("cq"));//field name in bean
    	cqCol.setMinWidth(100);
    	
    	TableColumn<CustomersBean, Float> cpCol=new TableColumn<CustomersBean, Float>("Cow price");
    	cpCol.setCellValueFactory(new PropertyValueFactory<>("cp"));//field name in bean
    	cpCol.setMinWidth(100);
    	
    	TableColumn<CustomersBean, Float> bqCol=new TableColumn<CustomersBean, Float>("Buffalo Quantity");
    	bqCol.setCellValueFactory(new PropertyValueFactory<>("bq"));//field name in bean
    	bqCol.setMinWidth(100);
    	
    	TableColumn<CustomersBean, Float> bpCol=new TableColumn<CustomersBean, Float>("Buffalo price");
    	bpCol.setCellValueFactory(new PropertyValueFactory<>("bp"));//field name in bean
    	bpCol.setMinWidth(100);
    	
    	TableColumn<CustomersBean,Integer> statusCol=new TableColumn<CustomersBean,Integer>("Status");
    	statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));//field name in bean
    	statusCol.setMinWidth(100);
    	
    	TableColumn<CustomersBean, String> dosCol=new TableColumn<CustomersBean, String>("Date of start");
    	dosCol.setCellValueFactory(new PropertyValueFactory<>("dos"));//field name in bean
    	dosCol.setMinWidth(100);
    	
    	tbl.getColumns().addAll(mobileCol,cnameCol,addressCol,areaCol,cityCol,cqCol,cpCol,bqCol,bpCol,statusCol,dosCol);
    	tbl.setItems(list);
    }
    
    @FXML
    void doExport(ActionEvent event) {
    	try {
			if(flag123==0)
				{
				showAlert("No data to export");
				return;
				}
    		writeExcel();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    boolean xxx=true;
    public void writeExcel()  throws Exception {
        Writer writer = null;
        try {
        	FileChooser chooser=new FileChooser();
	    	xxx=true;
        	chooser.setTitle("Select Path:");
        	
        	chooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("All Files", "*.*")
                    
                );
        	 File file=chooser.showSaveDialog(null);
        	 if(file==null)
        		 {
        		 xxx=false;
        		 return;
        		 }
        	String filePath=file.getAbsolutePath();
        	if((filePath.endsWith(".csv")||filePath.endsWith(".CSV")))
        	{
        		showAlert("file name should have .csv extension");
        		return;
        	}
        	 file = new File(filePath);        	 
            writer = new BufferedWriter(new FileWriter(file));
            String text="mobile,name,address,area,city,cow milk quantity,cow milk price,buffalo milk quantity,buffalo mik price,status,date of start\n";
            writer.write(text);
            for (CustomersBean p : list)
            {
				text = p.getMobile()+ "," + p.getCname()+ "," + p.getAddress()+ "," + p.getArea()+ "," + p.getCity()+ 
						"," + p.getCq()+ "," + p.getCp()+ "," + p.getBq()+ "," + p.getBp()+ "," + p.getStatus()
						+ "," + p.getDos()+"\n";
                writer.write(text);
            }
            showAlert("exported to excel");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        finally {
           if(xxx==false)
        	   return;
            writer.flush();
             writer.close();
        }
    }
    
    void doFill()
    {
    	ArrayList<String> names1=new ArrayList<>();
    	ArrayList<String> area1=new ArrayList<>();

		try {
		pst=con.prepareStatement("select distinct cname from customers");
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			String r=rs.getString("cname");
			names1.add(r);
		}
		pst=con.prepareStatement("select distinct area from customers");
		 rs=pst.executeQuery();
		while(rs.next())
		{
			String k=rs.getString("area");
			area1.add(k);
		}
		comboArea.getItems().clear();
		comboArea.getItems().addAll(area1);
		comboName.getItems().clear();
		comboName.getItems().addAll(names1);
    }
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
    }
    
    void showAlert(String msg)
   	{
   		Alert alert=new Alert(Alert.AlertType.INFORMATION);
   		alert.setContentText(msg);
   		alert.show();
   	}

    @FXML
    void initialize() {
    	assert comboArea != null : "fx:id=\"comboArea\" was not injected: check your FXML file 'CustomerFinder.fxml'.";
        assert comboName != null : "fx:id=\"comboName\" was not injected: check your FXML file 'CustomerFinder.fxml'.";
        assert tbl != null : "fx:id=\"tbl\" was not injected: check your FXML file 'CustomerFinder.fxml'.";
        doConnection();
        doFill();
    }
}
