package customerFinder;

public class CustomersBean {
	
	String mobile;
	String cname;
	String address;
	String area;
	String city;
	float cq;
	float cp;
	float bq;
	float bp;
	int status;
	String dos;
	
	CustomersBean()
	{
		
	}

	public CustomersBean(String mobile, String cname, String address, String area, String city, float cq, float cp,
			float bq, float bp, int status, String dos) {
		super();
		this.mobile = mobile;
		this.cname = cname;
		this.address = address;
		this.area = area;
		this.city = city;
		this.cq = cq;
		this.cp = cp;
		this.bq = bq;
		this.bp = bp;
		this.status = status;
		this.dos = dos;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public float getCq() {
		return cq;
	}

	public void setCq(float cq) {
		this.cq = cq;
	}

	public float getCp() {
		return cp;
	}

	public void setCp(float cp) {
		this.cp = cp;
	}

	public float getBq() {
		return bq;
	}

	public void setBq(float bq) {
		this.bq = bq;
	}

	public float getBp() {
		return bp;
	}

	public void setBp(float bp) {
		this.bp = bp;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getDos() {
		return dos;
	}

	public void setDos(String dos) {
		this.dos = dos;
	}
	

}
