package customerRegistration;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;

public class CustomerController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField mobile;

    @FXML
    private TextField cname;

    @FXML
    private TextArea address;

    @FXML
    private TextField area;

    @FXML
    private TextField city;

    @FXML
    private TextField cq;

    @FXML
    private TextField bq;

    @FXML
    private TextField cp;

    @FXML
    private TextField bp;

    @FXML
    private DatePicker dos;
    
    
    Connection con;
    PreparedStatement pst;
    
    void doConnection()
    {
    	try {
 		Class.forName("com.mysql.jdbc.Driver");
 		con=DriverManager.getConnection("jdbc:mysql://localhost/javafxproject",Data.uid,Data.pwd);
 		System.out.println("Connected");
 	} catch (ClassNotFoundException | SQLException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
    }


    @FXML
    void doClose(ActionEvent event) {
    	System.exit(0);
    }

    @FXML
    void doDelete(ActionEvent event) {
    	if(mobile.getText().equals(""))
    	{
    		showAlert("Plz enter mobile number");
    		return;
    	}
    	//matches numbers only
 		String regexStr1 = "^[0-9]*$";

 		//matches 10-digit numbers only
 		String regexStr2 = "^[0-9]{10}$";

 		//matches numbers and dashes, any order really.
 		String regexStr3 = "^[0-9\\-]*$";
 		
 		if (mobile.getText().matches(regexStr1)==false)
 		{
 			showAlert("Mobile number invalid...plz enter only numbers");
 			return;
 		}
 		if (mobile.getText().matches(regexStr2)==false)
 		{
 			showAlert("Mobile number invalid...plz enter 10 digit number");
 			return;
 		}
 		if (mobile.getText().matches(regexStr3)==false)
 		{
 			showAlert("Mobile number invalid...plz enter only numbers");
 			return;
 		}
    	try {
			pst=con.prepareStatement("delete from customers where mobile=?");
			pst.setString(1,(mobile.getText()));//fill data
	   		int count=pst.executeUpdate();//fire query-saving data in table
	   		if(count!=0)
	   		showAlert("Record Deleted...");
	   		else
	   			showAlert("Invalid id");
	   		
	   		clearAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    @FXML
    void doReset(ActionEvent event) {
         clearAll();
    }

    @FXML
    void doSave(ActionEvent event) {
     	if(mobile.getText().equals(""))
    	{
    		showAlert("Plz enter mobile number");
    		return;
    	}
     		//matches numbers only
     		String regexStr1 = "^[0-9]*$";

     		//matches 10-digit numbers only
     		String regexStr2 = "^[0-9]{10}$";

     		//matches numbers and dashes, any order really.
     		String regexStr3 = "^[0-9\\-]*$";
     		
     		if (mobile.getText().matches(regexStr1)==false)
     		{
     			showAlert("Mobile number invalid...plz enter only numbers");
     			return;
     		}
     		if (mobile.getText().matches(regexStr2)==false)
     		{
     			showAlert("Mobile number invalid...plz enter 10 digit number");
     			return;
     		}
     		if (mobile.getText().matches(regexStr3)==false)
     		{
     			showAlert("Mobile number invalid...plz enter only numbers");
     			return;
     		}
     		
     	if(dos.getValue()==null)
     	{
     		showAlert("plz select Date of start");
     		return;
     	}
    	try {
			pst=con.prepareStatement("insert into customers values(?,?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1,mobile.getText());
			pst.setString(2,cname.getText());
			pst.setString(3,address.getText());
			pst.setString(4,area.getText());
			pst.setString(5,city.getText());
			float cq1=0.0f,cp1=0.0f,bq1=0.0f,bp1=0.0f;
			if(cq.getText().equals("")==false)
				cq1=Float.parseFloat(cq.getText());
			if(cp.getText().equals("")==false)
				cp1=Float.parseFloat(cp.getText());
			if(bq.getText().equals("")==false)
				bq1=Float.parseFloat(bq.getText());
			if(bp.getText().equals("")==false)
				bp1=Float.parseFloat(bp.getText());
				
			pst.setFloat(6,cq1);
			pst.setFloat(7,cp1);
			pst.setFloat(8,bq1);
			pst.setFloat(9,bp1);
			pst.setInt(10, 1);
			LocalDate local=dos.getValue();
			Date dt=Date.valueOf(local);
			pst.setDate(11, dt);
			int c=pst.executeUpdate();
			if(c==1)
			showAlert("record inserted");
			else
				showAlert("error");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			

    }

    @FXML
    void doSearch(ActionEvent event) {
     	if(mobile.getText().equals(""))
    	{
    		showAlert("Plz enter mobile number");
    		return;
    	}
     	//matches numbers only
 		String regexStr1 = "^[0-9]*$";

 		//matches 10-digit numbers only
 		String regexStr2 = "^[0-9]{10}$";

 		//matches numbers and dashes, any order really.
 		String regexStr3 = "^[0-9\\-]*$";
 		
 		if (mobile.getText().matches(regexStr1)==false)
 		{
 			showAlert("Mobile number invalid...plz enter only numbers");
 			return;
 		}
 		if (mobile.getText().matches(regexStr2)==false)
 		{
 			showAlert("Mobile number invalid...plz enter 10 digit number");
 			return;
 		}
 		if (mobile.getText().matches(regexStr3)==false)
 		{
 			showAlert("Mobile number invalid...plz enter only numbers");
 			return;
 		}
    	try {
			pst=con.prepareStatement("select cname,address,area,city,cq,cp,bq,bp,dos from customers where mobile=?");
			pst.setString(1,(mobile.getText()));
			ResultSet res= pst.executeQuery();
			boolean flag=true;	
			if(res.next())
			{
			cname.setText(res.getString("cname"));
			address.setText(res.getString("address"));
			area.setText(res.getString("area"));
			city.setText(res.getString("city"));
			cq.setText(String.valueOf(res.getFloat("cq")));
			cp.setText(String.valueOf(res.getFloat("cp")));
			bq.setText(String.valueOf(res.getFloat("bq")));
			bp.setText(String.valueOf(res.getFloat("bp")));
			Date d=res.getDate("dos");
			LocalDate loc=d.toLocalDate();
			dos.setValue(loc);
			return;
			}
			showAlert("invalid uid");
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }

    @FXML
    void doUpdate(ActionEvent event) {
     	if(mobile.getText().equals(""))
    	{
    		showAlert("Plz enter mobile number");
    		return;
    	}
     	//matches numbers only
 		String regexStr1 = "^[0-9]*$";

 		//matches 10-digit numbers only
 		String regexStr2 = "^[0-9]{10}$";

 		//matches numbers and dashes, any order really.
 		String regexStr3 = "^[0-9\\-]*$";
 		
 		if (mobile.getText().matches(regexStr1)==false)
 		{
 			showAlert("Mobile number invalid...plz enter only numbers");
 			return;
 		}
 		if (mobile.getText().matches(regexStr2)==false)
 		{
 			showAlert("Mobile number invalid...plz enter 10 digit number");
 			return;
 		}
 		if (mobile.getText().matches(regexStr3)==false)
 		{
 			showAlert("Mobile number invalid...plz enter only numbers");
 			return;
 		}
     	if(dos.getValue()==null)
     	{
     		showAlert("plz select Date of start");
     		return;
     	}
    	try {
			pst=con.prepareStatement("update customers set cname=?,address=?,area=?,city=?,cq=?,cp=?,"
					+ "bq=?,bp=?,status=?,dos=? where mobile=?");
			
			pst.setString(1,cname.getText());
			pst.setString(2,address.getText());
			pst.setString(3,area.getText());
			pst.setString(4,city.getText());
			float cq1=0.0f,cp1=0.0f,bq1=0.0f,bp1=0.0f;
			if(cq.getText().equals("")==false)
				cq1=Float.parseFloat(cq.getText());
			if(cp.getText().equals("")==false)
				cp1=Float.parseFloat(cp.getText());
			if(bq.getText().equals("")==false)
				bq1=Float.parseFloat(bq.getText());
			if(bp.getText().equals("")==false)
				bp1=Float.parseFloat(bp.getText());
				
			pst.setFloat(5,cq1);
			pst.setFloat(6,cp1);
			pst.setFloat(7,bq1);
			pst.setFloat(8,bp1);
			pst.setInt(9, 1);
			LocalDate local=dos.getValue();
			Date dt=Date.valueOf(local);
			pst.setDate(10, dt);
			pst.setString(11,mobile.getText());
			
			int c=pst.executeUpdate();
			if(c==1)
			showAlert("record updated");
			else
				showAlert("error");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    void showAlert(String msg)
	{
		Alert alert=new Alert(Alert.AlertType.INFORMATION);
		alert.setContentText(msg);
		alert.show();
		
	}
    void clearAll()
    {
    	mobile.setText(null);
    	cname.setText(null);
    	address.setText(null);
    	area.setText(null);
    	city.setText(null);
    	bq.setText(null);
    	cq.setText(null);
    	cp.setText(null);
    	bp.setText(null);
    	dos.setValue(null);
    }

    @FXML
    void initialize() {
        assert mobile != null : "fx:id=\"mobile\" was not injected: check your FXML file 'Customer.fxml'.";
        assert cname != null : "fx:id=\"cname\" was not injected: check your FXML file 'Customer.fxml'.";
        assert address != null : "fx:id=\"address\" was not injected: check your FXML file 'Customer.fxml'.";
        assert area != null : "fx:id=\"area\" was not injected: check your FXML file 'Customer.fxml'.";
        assert city != null : "fx:id=\"city\" was not injected: check your FXML file 'Customer.fxml'.";
        assert cq != null : "fx:id=\"cq\" was not injected: check your FXML file 'Customer.fxml'.";
        assert bq != null : "fx:id=\"bq\" was not injected: check your FXML file 'Customer.fxml'.";
        assert cp != null : "fx:id=\"qp\" was not injected: check your FXML file 'Customer.fxml'.";
        assert bp != null : "fx:id=\"bp\" was not injected: check your FXML file 'Customer.fxml'.";
        assert dos != null : "fx:id=\"dos\" was not injected: check your FXML file 'Customer.fxml'.";
        doConnection();

    }
}

