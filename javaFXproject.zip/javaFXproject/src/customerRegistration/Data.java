package customerRegistration;

public class Data {

	public static final String uid="root";
	public static final String pwd="";
}
