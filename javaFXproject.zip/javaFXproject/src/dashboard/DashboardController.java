package dashboard;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class DashboardController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    @FXML
    private ImageView a;

    @FXML
    void doAbout(MouseEvent event) {
    	try{
    		
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("aboutUs/AboutUs.fxml")); 
			Scene scene = new Scene(root);
			
			Stage stage=new Stage();

			stage.setScene(scene);
			
			stage.show();

			//to hide the opened window
			 
			 /*  Scene scene1=(Scene)proceed.getScene();
			   scene1.getWindow().hide();*/
			 

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

    @FXML
    void doBillc(MouseEvent event) {
    	
    	try{
    		
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("billCollection/BillCollection.fxml")); 
			Scene scene = new Scene(root);
			
			Stage stage=new Stage();

			stage.setScene(scene);
			
			stage.show();

			//to hide the opened window
			 
			 /*  Scene scene1=(Scene)proceed.getScene();
			   scene1.getWindow().hide();*/
			 

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

    @FXML
    void doBlog(MouseEvent event) {
    	try{
    		
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("billLog/BillLog.fxml")); 
			Scene scene = new Scene(root);
			
			Stage stage=new Stage();

			stage.setScene(scene);
			
			stage.show();

			//to hide the opened window
			 
			 /*  Scene scene1=(Scene)proceed.getScene();
			   scene1.getWindow().hide();*/
			 

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

    @FXML
    void doFind(MouseEvent event) {
try{
    		
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("customerFinder/CustomerFinder.fxml")); 
			Scene scene = new Scene(root);
			
			Stage stage=new Stage();

			stage.setScene(scene);
			
			stage.show();

			//to hide the opened window
			 
			 /*  Scene scene1=(Scene)proceed.getScene();
			   scene1.getWindow().hide();*/
			 

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    @FXML
    void doGbill(MouseEvent event) {
    	try{
    		
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("generateBill/GenerateBill.fxml")); 
			Scene scene = new Scene(root);
			
			Stage stage=new Stage();

			stage.setScene(scene);
			
			stage.show();

			//to hide the opened window
			 
			 /*  Scene scene1=(Scene)proceed.getScene();
			   scene1.getWindow().hide();*/
			 

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

    @FXML
    void doRegister(MouseEvent event) {
    	try{
    		
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("customerRegistration/Customer.fxml")); 
			Scene scene = new Scene(root);
			
			Stage stage=new Stage();

			stage.setScene(scene);
			
			stage.show();

			//to hide the opened window
			 
			 /*  Scene scene1=(Scene)proceed.getScene();
			   scene1.getWindow().hide();*/
			 

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

    @FXML
    void doRlog(MouseEvent event) {
    	try{
    		
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("routinelog/Routinelog.fxml")); 
			Scene scene = new Scene(root);
			
			Stage stage=new Stage();

			stage.setScene(scene);
			
			stage.show();

			//to hide the opened window
			 
			 /*  Scene scene1=(Scene)proceed.getScene();
			   scene1.getWindow().hide();*/
			 

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

    @FXML
    void doRoh(MouseEvent event) {
    	try{
    		
			Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("routineHistory/RoutineHistory.fxml")); 
			Scene scene = new Scene(root);
			
			Stage stage=new Stage();

			stage.setScene(scene);
			
			stage.show();

			//to hide the opened window
			 
			 /*  Scene scene1=(Scene)proceed.getScene();
			   scene1.getWindow().hide();*/
			 

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

    @FXML
    void initialize() {

    }
}
