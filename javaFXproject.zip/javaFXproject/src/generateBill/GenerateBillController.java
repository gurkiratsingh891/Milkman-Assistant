package generateBill;

import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.ResourceBundle;

import customerRegistration.Data;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.util.converter.LocalDateStringConverter;

public class GenerateBillController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label bbill;

    @FXML
    private ListView<String> listMobile;
    

    @FXML
    private ListView<String> listName;

    @FXML
    private ComboBox<Integer> comboMonth;

    @FXML
    private ComboBox<Integer> comboYear;
    
    @FXML
    private TextField days;

    @FXML
    private TextField totalbill;

    @FXML
    private Label cbill;

    @FXML
    private Label tbq;

    @FXML
    private Label tcq;

    @FXML
    private Label bp;

    @FXML
    private Label cp;
    
    
    Connection con;
    PreparedStatement pst;
    
    void doConnection()
    {
    	try {
 		Class.forName("com.mysql.jdbc.Driver");
 		con=DriverManager.getConnection("jdbc:mysql://localhost/javafxproject",Data.uid,Data.pwd);
 		System.out.println("Connected");
 	} catch (ClassNotFoundException | SQLException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
    }
    boolean flag=false;
 
    @FXML
    void clkMonth(ActionEvent event) {
    	flag=true;
    	calDaysofMonth();
    }

    @FXML
    void clkYear(ActionEvent event) {
    
    	calDaysofMonth();

    }
    
    void calDaysofMonth()
    {
    	
    	if(flag==true)
    	{
    		int month=comboMonth.getSelectionModel().getSelectedItem();
    		int year=comboYear.getSelectionModel().getSelectedItem();
    		YearMonth yearMonthObject = YearMonth.of(year,month);
        	int daysInMonth = yearMonthObject.lengthOfMonth();
        	days.setText(String.valueOf(daysInMonth));
    	}
    }
    
float cprice=0.0f,bprice=0.0f;
	@FXML
    void doBill(ActionEvent event) {
		if(listMobile.getSelectionModel().getSelectedItem()==null)
    	{
    		showAlert("plz select mobile number");
    				return;
    	}
		else if(comboMonth.getSelectionModel().getSelectedItem()==null)
    	{
    		showAlert("plz select month");
    				return;
    	}
		try {
    		PreparedStatement pst2=con.prepareStatement("select * from customers where mobile=?");
			pst2.setString(1,listMobile.getSelectionModel().getSelectedItem());
			ResultSet res2=pst2.executeQuery();
			float cq1=0.0f,bq1=0.0f;
			if(res2.next())
			{
				 cq1=res2.getFloat("cq");
				 cprice=res2.getFloat("cp");
				 bq1=res2.getFloat("bq");
				 bprice=res2.getFloat("bp");
			}
			
    		
    		pst=con.prepareStatement("select * from bill_history where mobile=? and month=? and year=?");
    		int month12=comboMonth.getSelectionModel().getSelectedItem()-1;
    		System.out.println(month12+"f");
    				int year12=comboYear.getSelectionModel().getSelectedItem();
    				if(month12==0)
    				{
    					month12=12;
    					year12=year12-1;
    				}
			pst.setString(1,listMobile.getSelectionModel().getSelectedItem());
			pst.setInt(2,month12);
			pst.setInt(3,year12);

			ResultSet rs=pst.executeQuery();
			int billdays;
			int daysinmonth=Integer.parseInt(days.getText());
			if(rs.next())            // Existing customer
			{
			billdays=Integer.parseInt(days.getText());
			System.out.println("entrr");
			}
			else                //first time bill
			{
				Date startd=res2.getDate("dos");
				int a=startd.getDate();
				billdays=daysinmonth-a+1;
			}
			System.out.println(billdays);
			float regular_cq=cq1*billdays;
					float regular_bq= bq1*billdays;
					netQty(regular_cq,regular_bq);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    void netQty(float regular_cq,float regular_bq)
    {
    	try {
			PreparedStatement pst1=con.prepareStatement("select sum(cq),sum(bq)from routinelog where mobile=? and month=? and year=?");
			pst1.setString(1,listMobile.getSelectionModel().getSelectedItem());
			pst1.setInt(2,comboMonth.getSelectionModel().getSelectedItem());
			pst1.setInt(3,comboYear.getSelectionModel().getSelectedItem());
			ResultSet rs1=pst1.executeQuery();
			rs1.next();
			float var_cq =rs1.getFloat(1);
			System.out.println(var_cq);
			float var_bq=rs1.getFloat(2);
			float cownetqty=regular_cq+var_cq;
			float bnetqty=regular_bq+var_bq;
			netbill(cownetqty,bnetqty);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
    }
    void netbill(float cownetqty,float bnetqty)
    {
    	float cowbill=cprice*cownetqty;
    	float bufbill=bprice*bnetqty;
    	float tbill=cowbill+bufbill;
    	cp.setText(String.valueOf(cprice));
    	bp.setText(String.valueOf(bprice));
    	tcq.setText(String.valueOf(cownetqty));
    	tbq.setText(String.valueOf(bnetqty));
    	cbill.setText(String.valueOf(cowbill));
    	bbill.setText(String.valueOf(bufbill));
    	totalbill.setText(String.valueOf(tbill));
    	PreparedStatement pst1;
		try {
			pst1 = con.prepareStatement("insert into bill_history values(?,?,?,?,?,?,?,?,?)");
			pst1.setString(1,listMobile.getSelectionModel().getSelectedItem());
			pst1.setInt(8,comboMonth.getSelectionModel().getSelectedItem());
			pst1.setInt(9,comboYear.getSelectionModel().getSelectedItem());
			pst1.setInt(7,0);
			pst1.setFloat(4,cowbill);
			pst1.setFloat(5,bufbill);
			pst1.setFloat(6,tbill);
			pst1.setFloat(2, cownetqty);
			pst1.setFloat(3,bnetqty);

			pst1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }
    void doFill()
    {
    	ArrayList<String> names1=new ArrayList<>();
    	ArrayList<String> address1=new ArrayList<>();

		try {
		pst=con.prepareStatement("select mobile,cname from customers");
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			String r=rs.getString("cname");
			names1.add(r);
			String s=rs.getString("mobile");
			address1.add(s);
			
		}
		listName.getItems().clear();
		listName.getItems().addAll(names1);
		listMobile.getItems().clear();
		listMobile.getItems().addAll(address1);
    }
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	    }
		
		
		 void showAlert(String msg)
		   	{
		   		Alert alert=new Alert(Alert.AlertType.INFORMATION);
		   		alert.setContentText(msg);
		   		alert.show();
		   	}
    @FXML
    void initialize() {
    	ArrayList<Integer> allmonths=new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12));
    	comboMonth.getItems().addAll(allmonths);
    	ArrayList<Integer>allyears=new ArrayList<>(Arrays.asList(2018,2019,2020,2021,2022,2023,2024,2025));
    	comboYear.getItems().addAll(allyears);
    	Integer a=LocalDate.now().getYear();
    	comboYear.getSelectionModel().select(a);
    	doConnection();
        doFill();
    	assert bbill != null : "fx:id=\"bbill\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert listMobile != null : "fx:id=\"listMobile\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert listName != null : "fx:id=\"listName\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert comboMonth != null : "fx:id=\"comboMonth\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert days != null : "fx:id=\"days\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert totalbill != null : "fx:id=\"totalbill\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert cbill != null : "fx:id=\"cbill\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert tbq != null : "fx:id=\"tbq\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert tcq != null : "fx:id=\"tcq\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert bp != null : "fx:id=\"bp\" was not injected: check your FXML file 'GenerateBill.fxml'.";
        assert cp != null : "fx:id=\"cp\" was not injected: check your FXML file 'GenerateBill.fxml'.";

    }
}
