package routineHistory;

public class RoutineBean {
	int day;
	float cq;
	float bq;
	
	RoutineBean(){}
	public RoutineBean(int day, float cq, float bq) {
		super();
		this.day = day;
		this.cq = cq;
		this.bq = bq;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public float getCq() {
		return cq;
	}
	public void setCq(float cq) {
		this.cq = cq;
	}
	public float getBq() {
		return bq;
	}
	public void setBq(float bq) {
		this.bq = bq;
	}
	

}
