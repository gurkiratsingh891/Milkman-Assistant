package routineHistory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import customerFinder.CustomersBean;
import customerRegistration.Data;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.FileChooser;

public class RoutineHistoryController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<Integer> comboMonth;

    @FXML
    private ComboBox<Integer> comboYear;

    @FXML
    private ComboBox<String> comboMobile;

    @FXML
    private TableView<RoutineBean> tbl;
    Connection con;
    PreparedStatement pst;
    ObservableList<RoutineBean> list=FXCollections.observableArrayList();
    void doConnection()
    {
    	try {
 		Class.forName("com.mysql.jdbc.Driver");
 		con=DriverManager.getConnection("jdbc:mysql://localhost/javafxproject",Data.uid,Data.pwd);
 		System.out.println("Connected");
 	} catch (ClassNotFoundException | SQLException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
    }
    @FXML
    void doExport(ActionEvent event) {
    	 Writer writer = null;
         try {
         	FileChooser chooser=new FileChooser();
 	    	
         	chooser.setTitle("Select Path:");
         	
         	chooser.getExtensionFilters().addAll(
                     new FileChooser.ExtensionFilter("All Files", "*.*")
                     
                 );
         	 File file=chooser.showSaveDialog(null);
         	String filePath=file.getAbsolutePath();
         	if(!(filePath.endsWith(".csv")||filePath.endsWith(".CSV")))
         	{
         		showAlert("file name should have .csv extension");
         		return;
         	}
         	 file = new File(filePath);        	 
             writer = new BufferedWriter(new FileWriter(file));
             String text="Day,Cow milk quantity,Buffalo milk quantity\n";
             writer.write(text);
             for (RoutineBean p : list)
             {
 				text = p.getDay()+ "," + p.getCq()+ "," + p.getBq() + "\n";
                 writer.write(text);
             }
             showAlert("exported to excel");
         } catch (Exception ex) {
             ex.printStackTrace();
         }
         finally {
             try {
            	 writer.flush();
	              writer.close();


			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
         }

    }

    @FXML
    void doFilter(KeyEvent event) {
    	String a=comboMobile.getEditor().getText();
    	if(a.equals(""))
    	{
    		doFillMobiles();
    		return;
    	}
    	a="%"+a+"%";
    	ArrayList<String> mobiles=new ArrayList<>();
		try {
			pst=con.prepareStatement("select mobile from customers where mobile like ?");
			pst.setString(1, a);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String r=rs.getString("mobile");
				mobiles.add(r);
			}
			
			comboMobile.getItems().clear();
			comboMobile.getItems().addAll(mobiles);
			
			
	    }
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
    }
    void doFill()
    {
    	ArrayList<Integer> allmonths=new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12));
    	comboMonth.getItems().addAll(allmonths);
    	ArrayList<Integer>allyears=new ArrayList<>(Arrays.asList(2016,2017,2018,2019,2020,2021,2022,2023,2024,2025));
    	comboYear.getItems().addAll(allyears);
    	Integer a=LocalDate.now().getYear();
    	
    	comboYear.getSelectionModel().select(a);
		
    }

	void doFillMobiles()
	{
    	ArrayList<String> mobiles=new ArrayList<>();
		try {
			pst=con.prepareStatement("select distinct mobile from customers");
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String r=rs.getString("mobile");
				mobiles.add(r);
			}
			
			comboMobile.getItems().clear();
			comboMobile.getItems().addAll(mobiles);
			
	    }
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
	}

    @FXML
    void getHistory(ActionEvent event) {
    	list.clear();
    	if(comboMonth.getSelectionModel().getSelectedItem()==null)
    	{
    		showAlert("plz select month");
    		return;
    	}
    	int month=comboMonth.getSelectionModel().getSelectedItem();
		int year=comboYear.getSelectionModel().getSelectedItem();
		String mobile=comboMobile.getSelectionModel().getSelectedItem();
		if(mobile==null)
		{
			showAlert("plz enter mobile number");
			return;
		}
		int days=calDaysofMonth(month,year);
		try {
			pst=con.prepareStatement("select cq,bq from customers where mobile=?");
			pst.setString(1, mobile);
			ResultSet rs=pst.executeQuery();
			rs.next();
			float cq=rs.getFloat("cq");
			float bq=rs.getFloat("bq");
			pst=con.prepareStatement("select cq,bq,day from routinelog where mobile=? and month=? and year=? order by day");
			pst.setString(1, mobile);
			pst.setInt(2, month);
			pst.setInt(3, year);
			rs=pst.executeQuery();
			boolean a=rs.next();
			for(int i=1;i<=days;i++)
			{
				float ncq=cq;
				float nbq=bq;
				if(a==true&&rs.getInt("day")==i)
				{
					ncq=ncq+rs.getFloat("cq");
					nbq=nbq+rs.getFloat("bq");
					a=rs.next();
				}
				RoutineBean bean=new RoutineBean(i,ncq,nbq);
   				list.add(bean);
   				doTable();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }
    void doTable()
    {
tbl.getColumns().clear();
    	TableColumn<RoutineBean, Float> cqCol=new TableColumn<RoutineBean, Float>("Cow Milk Quantity");
    	cqCol.setCellValueFactory(new PropertyValueFactory<>("cq"));//field name in bean
    	cqCol.setMinWidth(130);
  
    	
    	TableColumn<RoutineBean, Float> bqCol=new TableColumn<RoutineBean, Float>("Buffalo Milk Quantity");
    	bqCol.setCellValueFactory(new PropertyValueFactory<>("bq"));//field name in bean
    	bqCol.setMinWidth(150);
    	
    	
    	TableColumn<RoutineBean,Integer> dayCol=new TableColumn<RoutineBean,Integer>("Day");
    	dayCol.setCellValueFactory(new PropertyValueFactory<>("day"));//field name in bean
    	dayCol.setMinWidth(50);
    	tbl.getColumns().addAll(dayCol,cqCol,bqCol);
    	tbl.setItems(list);
    }
    
    int calDaysofMonth(int month,int year)
    {
    		YearMonth yearMonthObject = YearMonth.of(year,month);
        	int daysInMonth = yearMonthObject.lengthOfMonth();
        	return daysInMonth;
    	
    }
    void showAlert(String msg)
   	{
   		Alert alert=new Alert(Alert.AlertType.INFORMATION);
   		alert.setContentText(msg);
   		alert.show();
   	}
    @FXML
    void initialize() {
        assert comboMonth != null : "fx:id=\"comboMonth\" was not injected: check your FXML file 'RoutineHistory.fxml'.";
        assert comboYear != null : "fx:id=\"comboYear\" was not injected: check your FXML file 'RoutineHistory.fxml'.";
        assert comboMobile != null : "fx:id=\"comboMobile\" was not injected: check your FXML file 'RoutineHistory.fxml'.";
        assert tbl != null : "fx:id=\"tbl\" was not injected: check your FXML file 'RoutineHistory.fxml'.";
        doConnection();
        doFill();
        doFillMobiles();
    }
}
