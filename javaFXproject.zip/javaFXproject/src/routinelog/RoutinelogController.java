package routinelog;

import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.ResourceBundle;

import customerRegistration.Data;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class RoutinelogController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ListView<String>  listAddress;

    @FXML
    private ListView<String> listName;

    @FXML
    private TextField cq;

    @FXML
    private TextField bq;

    @FXML
    private TextField mobile;

    @FXML
    private TextField ucq;

    @FXML
    private TextField ubq;

    @FXML
    private CheckBox chkskip;
    
    @FXML
    private DatePicker datepicker;
    
    
    Connection con;
    PreparedStatement pst;
    
    void doConnection()
    {
    	try {
 		Class.forName("com.mysql.jdbc.Driver");
 		con=DriverManager.getConnection("jdbc:mysql://localhost/javafxproject",Data.uid,Data.pwd);
 		System.out.println("Connected");
 	} catch (ClassNotFoundException | SQLException e) {
 		// TODO Auto-generated catch block
 		e.printStackTrace();
 	}
    }

    @FXML
    void doDelete(ActionEvent event) {
    	ObservableList<String>indi=listName.getSelectionModel().getSelectedItems();
    	ObservableList<String>indii=listAddress.getSelectionModel().getSelectedItems();
    	listName.getItems().retainAll(indi);
    	listAddress.getItems().retainAll(indii);
    	listName.getSelectionModel().clearSelection();
    	listAddress.getSelectionModel().clearSelection();

    }

    @FXML
    void doUpdate(ActionEvent event) {
    	listName.getItems().remove(listName.getSelectionModel().getSelectedItem());
    	listAddress.getItems().remove(listAddress.getSelectionModel().getSelectedItem());
    	listName.getSelectionModel().clearSelection();
    	listAddress.getSelectionModel().clearSelection();
    	

    	Float a;
    	Float b;
   	 LocalDate local=datepicker.getValue();
   	int da= local.getDayOfMonth();
   	int mo=local.getMonthValue();
   	int y= local.getYear();
	 
	 System.out.println(da+"  "+mo+"  "+y);
    	if(chkskip.isSelected())
    	{
    		a=-Float.parseFloat(cq.getText());
    		b=-Float.parseFloat(bq.getText());
    	}
    	else
    	{
    		a=Float.parseFloat(ucq.getText());
    		b=Float.parseFloat(ubq.getText());
    	}
    try {
    	System.out.println(a+" "+b);
    	pst=con.prepareStatement("insert into routinelog values(?,?,?,?,?,?)");
		pst.setString(1,mobile.getText());
		pst.setFloat(2,a);
		pst.setFloat(3,b);
		pst.setInt(4,mo);
		pst.setInt(5,y);
		pst.setInt(6,da);
		int c=pst.executeUpdate();
		if(c==1)
		showAlert("Routine Log updated");
		else
			showAlert("error");
    }
    catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
   	 
    	mobile.setText("");
    	cq.setText("");
    	bq.setText("");
    	ucq.setText("");
    	ubq.setText("");
    	chkskip.setSelected(false);
    	}
    	
    @FXML
    void doclick(MouseEvent event) {
    	int c=event.getClickCount();
    	if(c==1)
    	{
    		listAddress.getSelectionModel().clearSelection();
        	ObservableList<Integer>indices=listName.getSelectionModel().getSelectedIndices();
        	for (Integer integer : indices) {
    			listAddress.getSelectionModel().select(integer);
    		}
    	}
    	else if(c==2)
    	{
    		
    			try {
					pst=con.prepareStatement("select mobile,cq,bq from customers where cname=? and address=?");
					pst.setString(1,listName.getSelectionModel().getSelectedItem());
					pst.setString(2,listAddress.getSelectionModel().getSelectedItem());
					ResultSet rs=pst.executeQuery();
	    			if(rs.next())
	    			{
	    				mobile.setText(rs.getString("mobile"));
	    				cq.setText(String.valueOf(rs.getFloat("cq")));
	    				bq.setText(String.valueOf(rs.getFloat("bq")));
	    			}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    	}

    }
    void showAlert(String msg)
   	{
   		Alert alert=new Alert(Alert.AlertType.INFORMATION);
   		alert.setContentText(msg);
   		alert.show();
   		
   	}
    void doFill()
    {
    	ArrayList<String> names1=new ArrayList<>();
    	ArrayList<String> address1=new ArrayList<>();

		try {
		pst=con.prepareStatement("select cname,address from customers");
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			String r=rs.getString("cname");
			names1.add(r);
			String s=rs.getString("address");
			address1.add(s);
			
		}
		listName.getItems().clear();
		listName.getItems().addAll(names1);
		listAddress.getItems().clear();
		listAddress.getItems().addAll(address1);
	 
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
	}
    }

    @FXML
    void initialize() {
        assert listAddress != null : "fx:id=\"listAddress\" was not injected: check your FXML file 'Routinelog.fxml'.";
        assert listName != null : "fx:id=\"listName\" was not injected: check your FXML file 'Routinelog.fxml'.";
        assert cq != null : "fx:id=\"cq\" was not injected: check your FXML file 'Routinelog.fxml'.";
        assert bq != null : "fx:id=\"qp\" was not injected: check your FXML file 'Routinelog.fxml'.";
        assert mobile != null : "fx:id=\"mobile\" was not injected: check your FXML file 'Routinelog.fxml'.";
        assert ucq != null : "fx:id=\"ucq\" was not injected: check your FXML file 'Routinelog.fxml'.";
        assert ubq != null : "fx:id=\"ubq\" was not injected: check your FXML file 'Routinelog.fxml'.";
        assert chkskip != null : "fx:id=\"skip\" was not injected: check your FXML file 'Routinelog.fxml'.";
        listName.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    	listAddress.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);//multiple selection mode
        doConnection();
        doFill();
        

    }
}
